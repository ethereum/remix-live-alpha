(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[6],{

/***/ 2882:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("import { BytesLike } from \"@ethersproject/bytes\";\nimport { BigNumberish } from \"@ethersproject/bignumber\";\nexport declare function getAddress(address: string): string;\nexport declare function isAddress(address: string): boolean;\nexport declare function getIcapAddress(address: string): string;\nexport declare function getContractAddress(transaction: {\n    from: string;\n    nonce: BigNumberish;\n}): string;\nexport declare function getCreate2Address(from: string, salt: BytesLike, initCodeHash: BytesLike): string;\n//# sourceMappingURL=index.d.ts.map");

/***/ })

}]);
//# sourceMappingURL=raw-loader!-ethersproject-address-lib-index-d-ts.0.24.0-dev.1652384793841.js.map
//# sourceMappingURL=raw-loader!-ethersproject-address-lib-index-d-ts.0.24.0-dev.1652384793841.js.map