(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[23],{

/***/ 2916:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("import { BytesLike } from \"@ethersproject/bytes\";\nexport declare function encode(object: any): string;\nexport declare function decode(data: BytesLike): any;\n//# sourceMappingURL=index.d.ts.map");

/***/ })

}]);
//# sourceMappingURL=raw-loader!-ethersproject-rlp-lib-index-d-ts.0.25.0-dev.1657526109965.js.map
//# sourceMappingURL=raw-loader!-ethersproject-rlp-lib-index-d-ts.0.25.0-dev.1657526109965.js.map